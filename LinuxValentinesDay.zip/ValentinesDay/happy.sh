#!/bin/sh

cd "$(dirname "$0")"
pactl -- set-sink-volume 0 20%
./tree
mpg123 twpCHFL.mp3